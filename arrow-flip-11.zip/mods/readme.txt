You can either edit files or add entirely new ones here.

ABOUT EDITTING:
It doesn't matter if you want to edit something in assets/shared/images/ or assets/preload/images/,
you will have to put the editted files in mods/images/, it will be handled automatically by the engine.